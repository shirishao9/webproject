package com.example.student.StudentRecords;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentRecordsApplicationTests {

	@Test
	void contextLoads() {
	}

}
